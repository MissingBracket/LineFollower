//#define bool int
#define true 1
#define false 0
#include "stm32f4xx_tim.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_exti.h"
#include "stm32f4xx_adc.h"
#include "misc.h"
#include "stm32f4xx_usart.h"
#include "stm32f4xx_dac.h"
volatile int timercount=0;
GPIO_InitTypeDef PortA;
int cz1=0,cz2=0,cz3=0;
//cz1=cz2=cz3=0;
int qcontrol = 0;
int switchr = 0;

//***Odczyt ADC
int ADC_Result;
float ADC_Result1;
float Volt;

enum SterowanieSilnikiem{
	Przod,Tyl,Stop,REST
};
int Kierunek=REST;
void TIM3_IRQHandler(void)
{
         	if(TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
         	{
         		//GPIO_ToggleBits(GPIOD, GPIO_Pin_15);
                // miejsce na kod wywo�ywany w momencie wyst�pienia przerwania

       			PortA.GPIO_Mode = GPIO_Mode_OUT;
         		PortA.GPIO_OType = GPIO_OType_PP;
         		PortA.GPIO_Speed = GPIO_Speed_100MHz;
         		PortA.GPIO_PuPd = GPIO_PuPd_NOPULL;
         		GPIO_Init(GPIOA, &PortA);
                // wyzerowanie flagi wyzwolonego przerwania
         		//GPIO_ToggleBits(GPIOD,GPIO_Pin_15);

         		GPIO_SetBits(GPIOA,GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7);
         		TIM_Cmd(TIM2,ENABLE);

         		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
         	}
}
void TIM2_IRQHandler(void)
{
         	if(TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
         	{
         		//GPIO_ToggleBits(GPIOD, GPIO_Pin_15);
                // miejsce na kod wywo�ywany w momencie wyst�pienia przerwania

         			PortA.GPIO_Mode = GPIO_Mode_IN;
       				PortA.GPIO_OType = GPIO_OType_PP;
       				PortA.GPIO_Speed = GPIO_Speed_100MHz;
       				PortA.GPIO_PuPd = GPIO_PuPd_DOWN;
      				GPIO_Init(GPIOA, &PortA);
      			/*	cz1 = GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_5);
      				cz2 = GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6);
      				cz3 = GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_7);*/
                	// wyzerowanie flagi wyzwolonego przerwania
      				TIM_Cmd(TIM2,DISABLE);
      				TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
         	}
}
void initTimer3(){
	TIM_TimeBaseInitTypeDef Timer3;
		Timer3.TIM_Period = 8399;
		Timer3.TIM_Prescaler = 9999;
		Timer3.TIM_ClockDivision = TIM_CKD_DIV1;
		Timer3.TIM_CounterMode =  TIM_CounterMode_Up;
		TIM_TimeBaseInit(TIM3, &Timer3);
		TIM_Cmd(TIM3, ENABLE);
}
void initTimer2(){
	TIM_TimeBaseInitTypeDef Timer2;
		Timer2.TIM_Period = 41;
		Timer2.TIM_Prescaler = 19;
		Timer2.TIM_ClockDivision = TIM_CKD_DIV1;
		Timer2.TIM_CounterMode =  TIM_CounterMode_Up;
		TIM_TimeBaseInit(TIM2, &Timer2);
		TIM_Cmd(TIM2, ENABLE);
}
void initNVIC(){
	NVIC_InitTypeDef NVIC_InitStructure;
	// numer przerwania
	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
	// priorytet g��wny
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00;
	// subpriorytet
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;
	// uruchom dany kana�
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	// zapisz wype�nion� struktur� do rejestr�w
	NVIC_Init(&NVIC_InitStructure);
	// wyczyszczenie przerwania od timera 3 (wyst�pi�o przy konfiguracji timera)
	TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
	// zezwolenie na przerwania od przepe�nienia dla timera 3
	TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);
}
void portD(){
	GPIO_InitTypeDef PortD;
	PortD.GPIO_Pin =
	GPIO_Pin_12 | GPIO_Pin_13| GPIO_Pin_14| GPIO_Pin_15;
	PortD.GPIO_Mode = GPIO_Mode_OUT;
	PortD.GPIO_OType = GPIO_OType_PP;
	PortD.GPIO_Speed = GPIO_Speed_100MHz;
	PortD.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOD, &PortD);

	PortA.GPIO_Pin =
	GPIO_Pin_5| GPIO_Pin_6| GPIO_Pin_7;
	PortA.GPIO_Mode = GPIO_Mode_OUT;
	PortA.GPIO_OType = GPIO_OType_PP;
	PortA.GPIO_Speed = GPIO_Speed_100MHz;
	PortA.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOA, &PortA);
	//GPIO_SetBits(GPIOA, GPIO_Pin_5| GPIO_Pin_6| GPIO_Pin_7);
}
void initadc(){
	GPIO_InitTypeDef PortA;
		//inicjalizacja wej�cia ADC
	PortA.GPIO_Pin = GPIO_Pin_1;
	PortA.GPIO_Mode = GPIO_Mode_AN;
	PortA.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOA, &PortA);

	ADC_CommonInitTypeDef ADC_CommonInitStructure;
	// niezale�ny tryb pracy przetwornik�w
	ADC_CommonInitStructure.ADC_Mode = ADC_Mode_Independent;
	// zegar g��wny podzielony przez 2
	ADC_CommonInitStructure.ADC_Prescaler = ADC_Prescaler_Div2;
	// opcja istotna tylko dla trybu multi ADC
	ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;
	// czas przerwy pomi�dzy kolejnymi konwersjami
	ADC_CommonInitStructure.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
	ADC_CommonInit(&ADC_CommonInitStructure);

	ADC_InitTypeDef ADC_InitStructure;
	//ustawienie rozdzielczo�ci przetwornika na maksymaln� (12 bit�w)
	ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
	//wy��czenie trybu skanowania (odczytywa� b�dziemy jedno wej�cie ADC
	//w trybie skanowania automatycznie wykonywana jest konwersja na wielu //wej�ciach/kana�ach)
	ADC_InitStructure.ADC_ScanConvMode = DISABLE;
	//w��czenie ci�g�ego trybu pracy
	ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
	//wy��czenie zewn�trznego wyzwalania
	//konwersja mo�e by� wyzwalana timerem, stanem wej�cia itd. (szczeg�y w //dokumentacji)
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T1_CC1;
	ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
	//warto�� binarna wyniku b�dzie podawana z wyr�wnaniem do prawej
	//funkcja do odczytu stanu przetwornika ADC zwraca warto�� 16-bitow�
	//dla przyk�adu, warto�� 0xFF wyr�wnana w prawo to 0x00FF, w lewo 0x0FF0
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
	//liczba konwersji r�wna 1, bo 1 kana�
	ADC_InitStructure.ADC_NbrOfConversion = 1;
	// zapisz wype�nion� struktur� do rejestr�w przetwornika numer 1
	ADC_Init(ADC1, &ADC_InitStructure);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 1, ADC_SampleTime_84Cycles);
	ADC_Cmd(ADC1, ENABLE);
}
void init_PWM(int period, int prescaler){
	TIM_TimeBaseInitTypeDef Timer4;
	Timer4.TIM_Period = period;
	Timer4.TIM_Prescaler = prescaler;
	Timer4.TIM_ClockDivision = TIM_CKD_DIV1;
	Timer4.TIM_CounterMode =  TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM4, &Timer4);
	TIM_Cmd(TIM4, ENABLE);
	GPIO_InitTypeDef PortB;
	PortB.GPIO_Pin =
	GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7| GPIO_Pin_8| GPIO_Pin_9| GPIO_Pin_4;
	PortB.GPIO_Mode = GPIO_Mode_OUT;
	PortB.GPIO_OType = GPIO_OType_PP;
	PortB.GPIO_Speed = GPIO_Speed_100MHz;
	PortB.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOB, &PortB);

	TIM_OCInitTypeDef TIM_OCInitStructure;
	    /* PWM1 Mode configuration: */
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse = 0;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;


	TIM_OC1Init(TIM4, &TIM_OCInitStructure);
	TIM_OC1PreloadConfig(TIM4, TIM_OCPreload_Enable);

	GPIO_PinAFConfig(GPIOB, GPIO_PinSource6, GPIO_AF_TIM4);
	PortB.GPIO_Pin = GPIO_Pin_6;
	PortB.GPIO_Mode = GPIO_Mode_AF;
	GPIO_Init(GPIOB, &PortB);

	TIM_OC2Init(TIM4, &TIM_OCInitStructure);
	TIM_OC2PreloadConfig(TIM4, TIM_OCPreload_Enable);

	GPIO_PinAFConfig(GPIOB, GPIO_PinSource4, GPIO_AF_TIM4);
	PortB.GPIO_Pin = GPIO_Pin_4;
	PortB.GPIO_Mode = GPIO_Mode_AF;
	GPIO_Init(GPIOB, &PortB);
	TIM_OC3Init(TIM4, &TIM_OCInitStructure);
			TIM_OC3PreloadConfig(TIM4, TIM_OCPreload_Enable);

			GPIO_PinAFConfig(GPIOB, GPIO_PinSource8, GPIO_AF_TIM4);
			PortB.GPIO_Pin = GPIO_Pin_8;
			PortB.GPIO_Mode = GPIO_Mode_AF;
			GPIO_Init(GPIOB, &PortB);

	GPIO_ResetBits(GPIOB,GPIO_Pin_7|GPIO_Pin_5);
	Kierunek = REST;
}
void Projekt_Init(){
	portD();//GPIO_ToggleBits(GPIOD,GPIO_Pin_12);
	initTimer3();//GPIO_ToggleBits(GPIOD,GPIO_Pin_13);
	initNVIC();//GPIO_ToggleBits(GPIOD,GPIO_Pin_14);
	init_PWM(99,41);
	initadc();
}
void SetSpeed(int speed, char dir){
	switch(dir){
	case 'l':
		TIM4->CCR1 = speed;
		break;
	case 'r':
		TIM4->CCR3 = speed;
		break;
	}
}
void Sterowanie(int Kier){
switch(Kier){
case Przod:
	if(Kierunek == Przod)return;
	else {GPIO_ResetBits(GPIOB,GPIO_Pin_5 | GPIO_Pin_7);
	GPIO_SetBits(GPIOB,GPIO_Pin_7);
	}
	break;
case Tyl:
	if(Kierunek == Tyl)return;
	else {GPIO_ResetBits(GPIOB,GPIO_Pin_5 | GPIO_Pin_7);
	GPIO_SetBits(GPIOB, GPIO_Pin_5);
	}
	break;
case Stop:
	GPIO_ResetBits(GPIOB,GPIO_Pin_5 | GPIO_Pin_7);
	break;
}

}

void main(){
	SystemInit();
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA , ENABLE); // zegar dla portu GPIO z kt�rego wykorzystany zostanie pin jako wyj�cie DAC (PA4)
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC , ENABLE); // zegar dla portu GPIO z kt�rego wykorzystany zostanie pin jako wyj�cie DAC (PA4)
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB , ENABLE); // zegar dla portu GPIO z kt�rego wykorzystany zostanie pin jako wyj�cie DAC (PA4)
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD , ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);//Timer 3
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);//Timer 3
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);//Timer 3
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1); // Interrupt controller
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE); // zegar dla modu�u ADC1
//******CUSTOM FUNCTIONS FOR INIT
Projekt_Init();
SetSpeed(10,'l');
SetSpeed(10,'r');
//******END OF CUSTOM INITS

	while (true){
		timercount = TIM3->CNT;

		cz1 = GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_5);
		cz2 = GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6);
		cz3 = GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_7);

		ADC_SoftwareStartConv(ADC1);
		while(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET);
		ADC_Result = ADC_GetConversionValue(ADC1);

		/*if(cz1)GPIO_SetBits(GPIOD,GPIO_Pin_12);
				else GPIO_ResetBits(GPIOD,GPIO_Pin_12);
		if(cz2)GPIO_SetBits(GPIOD,GPIO_Pin_13);
				else GPIO_ResetBits(GPIOD,GPIO_Pin_13);
		if(cz3)GPIO_SetBits(GPIOD,GPIO_Pin_14);
				else GPIO_ResetBits(GPIOD,GPIO_Pin_14);*/
	}

}
