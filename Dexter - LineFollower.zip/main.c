#define true 1
#define false 0
#include "stm32f4xx_tim.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_exti.h"
#include "stm32f4xx_adc.h"
#include "misc.h"
#include "stm32f4xx_usart.h"
#include "stm32f4xx_dac.h"
volatile int timercount=0;
GPIO_InitTypeDef PortA;
GPIO_InitTypeDef PortE;
int Ladowanie=0;int Ladowanie2=0;
int qcontrol = 0;
int switchr = 0;
int cunter=0;int cunter2=0;
//***Odczyt ADC
int ADC_Result;
float ADC_Result1;
float Volt;
uint8_t deb1,deb2,deb3,deb4,deb5,deb6,deb7,deb8,deb9;
uint8_t sensorselect=0;
uint8_t Sensorarray[9]={0};
int isBlack(int x);
int None(){return !(Sensorarray[0] && Sensorarray[1] && Sensorarray[2] && Sensorarray[3] && Sensorarray[4] &&
		Sensorarray[5] && Sensorarray[6] && Sensorarray[7] &&Sensorarray[8]);}
enum SterowanieSilnikiem{
	Przod,Tyl,Stop,REST
};
int Kierunek=REST;
void InitSensor();
void SenSelect();
int debug=0;
void AllForth(){Sterowanie(Przod, 'l'); Sterowanie(Przod, 'r');}
void managedir(){
if(Sensorarray[4] && !(Sensorarray[3] || Sensorarray[5])){
	Sterowanie(Przod,'l');
	Sterowanie(Przod,'r');
	SetSpeed(15,'l');
	SetSpeed(15,'r');
}
else if(Sensorarray[3]&& ! Sensorarray[8]){AllForth();SetSpeed(10,'r');SetSpeed(20,'l');}
else if(Sensorarray[5]&& ! Sensorarray[0]){AllForth();SetSpeed(10,'l');SetSpeed(20,'r');}

else if(Sensorarray[2] && ! Sensorarray[8]){AllForth();SetSpeed(2,'r');SetSpeed(25,'l');}
else if(Sensorarray[6] && ! Sensorarray[0]){AllForth();SetSpeed(2,'l');SetSpeed(25,'r');}

else if(Sensorarray[0]){Sterowanie(Tyl, 'l'); SetSpeed(30,'r');SetSpeed(20,'l');}
else if(Sensorarray[8]){Sterowanie(Tyl, 'r'); SetSpeed(30,'l');SetSpeed(20,'r');}



}
void TIM3_IRQHandler(void){
         	if(TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET){
         		PortE.GPIO_Mode = GPIO_Mode_OUT;
         		PortE.GPIO_OType = GPIO_OType_PP;
         		PortE.GPIO_Speed = GPIO_Speed_100MHz;
         		PortE.GPIO_PuPd = GPIO_PuPd_NOPULL;
         		GPIO_Init(GPIOE, &PortE);	Ladowanie=0;Ladowanie2=0;
         		cunter = 0;
         		managedir();
         		cunter2 = 0;
         		GPIO_SetBits(GPIOE,
         				GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6 |
         				GPIO_Pin_7 | GPIO_Pin_8 |GPIO_Pin_9 |
         				GPIO_Pin_10 |GPIO_Pin_11 |GPIO_Pin_12
         				);
         		sensorselect=0;
         		TIM_Cmd(TIM2,ENABLE);
         		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
         	}
}
void TIM2_IRQHandler(void){
        	if(TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET){
         		if(cunter == 2){
         			PortE.GPIO_Mode = GPIO_Mode_IN;
       				PortE.GPIO_OType = GPIO_OType_OD;
       				PortE.GPIO_Speed = GPIO_Speed_100MHz;
       				PortE.GPIO_PuPd = GPIO_PuPd_NOPULL;
      				GPIO_Init(GPIOE, &PortE);
      				Ladowanie = 1;
         		}
      				cunter++;
      			if(cunter > 2)if(Ladowanie)SenSelect();
      				TIM_ClearITPendingBit(TIM2, TIM_IT_Update);

         	}
}
void TIM7_IRQHandler(void){
        	if(TIM_GetITStatus(TIM7, TIM_IT_Update) != RESET){
      			TIM_ClearITPendingBit(TIM7, TIM_IT_Update);
         	}
}
//Left-To-Right
/*
 *
 0-1-2-3			-5- 6 -7 -8
 8-7-9-6- MID>4<MID -5-10-12-11
 */
void SenSelect(){
	switch(sensorselect){
	case 0:
		if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_4) == 0){
		if(isBlack(cunter))Sensorarray[4]=1;
		else Sensorarray[4]=0;
		deb5=Sensorarray[4];
		sensorselect=1;
		InitSensor();

		}
		break;
	case 1:
		if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_6) == 0){
		if(isBlack(cunter))Sensorarray[3]=1;
		else Sensorarray[3]=0;
		deb4=Sensorarray[3];
		sensorselect=2;

		InitSensor();
		}
		break;
	case 2:
		if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_5) == 0){
		if(isBlack(cunter))Sensorarray[5]=1;
		else Sensorarray[5]=0;
		deb6=Sensorarray[5];
		sensorselect=3;
		InitSensor();}

		break;
	case 3:
			if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_9) == 0){
			if(isBlack(cunter))Sensorarray[2]=1;
			else Sensorarray[2]=0;
			deb3=Sensorarray[2];
			sensorselect=4;
			InitSensor();
					}
			break;
	case 4:
			if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_10) == 0){
			if(isBlack(cunter))Sensorarray[6]=1;
			else Sensorarray[6]=0;
			deb7=Sensorarray[6];
			sensorselect=7;
			InitSensor();
					}
			break;
	case 5:
			if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_7) == 0){
			if(isBlack(cunter))Sensorarray[1]=1;
			else Sensorarray[1]=0;
			deb2=cunter;
			sensorselect=6;
			InitSensor();
					}
			break;
	case 6:
			if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_12) == 0){
			if(isBlack(cunter))Sensorarray[7]=1;
			else Sensorarray[7]=0;
			deb8=Sensorarray[7];
			sensorselect=7;
			InitSensor();
					}
			break;
	case 7:
			if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_8) == 0){
			if(isBlack(cunter))Sensorarray[0]=1;
			else Sensorarray[0]=0;
			deb1=Sensorarray[0];
			sensorselect=8;
			InitSensor();
					}
			break;
	case 8:
			if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_11) == 0){
			if(isBlack(cunter))Sensorarray[8]=1;
			else Sensorarray[8]=0;
			deb9=Sensorarray[8];
			sensorselect=0;
			TIM_Cmd(TIM2, DISABLE);}
			break;
	default:
		TIM_Cmd(TIM2, DISABLE);
		break;
	}

}
void InitSensor(){
	PortE.GPIO_Mode = GPIO_Mode_OUT;
	PortE.GPIO_OType = GPIO_OType_PP;
	PortE.GPIO_Speed = GPIO_Speed_100MHz;
	PortE.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOE, &PortE);
	Ladowanie=0;
	cunter = 0;
	debug=75;
	GPIO_SetBits(GPIOE,
				GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6 |
				GPIO_Pin_7 | GPIO_Pin_8 |GPIO_Pin_9 |
				GPIO_Pin_10 | GPIO_Pin_11 |GPIO_Pin_12
				);
}
void initTimer3(){
	TIM_TimeBaseInitTypeDef Timer3;
	Timer3.TIM_Period = 419;
	Timer3.TIM_Prescaler = 9999;
	Timer3.TIM_ClockDivision = TIM_CKD_DIV1;
	Timer3.TIM_CounterMode =  TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM3, &Timer3);
	TIM_Cmd(TIM3, ENABLE);
}
void initTimer6(){
	TIM_TimeBaseInitTypeDef Timer6;
	Timer6.TIM_Period = 50;
	Timer6.TIM_Prescaler = 20;
	Timer6.TIM_ClockDivision = TIM_CKD_DIV1;
	Timer6.TIM_CounterMode =  TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM7, &Timer6);
	TIM_Cmd(TIM7, ENABLE);
}
void initTimer2(){
	TIM_TimeBaseInitTypeDef Timer2;
		Timer2.TIM_Period = 41;
		Timer2.TIM_Prescaler = 19;
		Timer2.TIM_ClockDivision = TIM_CKD_DIV1;
		Timer2.TIM_CounterMode =  TIM_CounterMode_Up;
		TIM_TimeBaseInit(TIM2, &Timer2);
		TIM_Cmd(TIM2, ENABLE);
}
void initNVIC(){
	NVIC_InitTypeDef NVIC_InitStructure;
	// numer przerwania
	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
	// priorytet g��wny
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x00;
	// subpriorytet
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;
	// uruchom dany kana�
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	// zapisz wype�nion� struktur� do rejestr�w
	NVIC_Init(&NVIC_InitStructure);
	// wyczyszczenie przerwania od timera 3 (wyst�pi�o przy konfiguracji timera)
	TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
	// zezwolenie na przerwania od przepe�nienia dla timera 3
	TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);

	NVIC_InitTypeDef NVIC_InitStructure2;
		// numer przerwania
		NVIC_InitStructure2.NVIC_IRQChannel = TIM2_IRQn;
		// priorytet g��wny
		NVIC_InitStructure2.NVIC_IRQChannelPreemptionPriority = 0x00;
		// subpriorytet
		NVIC_InitStructure2.NVIC_IRQChannelSubPriority = 0x00;
		// uruchom dany kana�
		NVIC_InitStructure2.NVIC_IRQChannelCmd = ENABLE;
		// zapisz wype�nion� struktur� do rejestr�w
		NVIC_Init(&NVIC_InitStructure2);
		// wyczyszczenie przerwania od timera 3 (wyst�pi�o przy konfiguracji timera)
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
		// zezwolenie na przerwania od przepe�nienia dla timera 3
		TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);

		NVIC_InitTypeDef NVIC_InitStructure6;
				// numer przerwania
				NVIC_InitStructure6.NVIC_IRQChannel = TIM7_IRQn;
				// priorytet g��wny
				NVIC_InitStructure6.NVIC_IRQChannelPreemptionPriority = 0x00;
				// subpriorytet
				NVIC_InitStructure6.NVIC_IRQChannelSubPriority = 0x00;
				// uruchom dany kana�
				NVIC_InitStructure6.NVIC_IRQChannelCmd = ENABLE;
				// zapisz wype�nion� struktur� do rejestr�w
				NVIC_Init(&NVIC_InitStructure6);
				// wyczyszczenie przerwania od timera 3 (wyst�pi�o przy konfiguracji timera)
				TIM_ClearITPendingBit(TIM7, TIM_IT_Update);
				// zezwolenie na przerwania od przepe�nienia dla timera 3
				TIM_ITConfig(TIM7, TIM_IT_Update, ENABLE);
}
void portD(){
	GPIO_InitTypeDef PortD;
	PortD.GPIO_Pin =
	GPIO_Pin_12 | GPIO_Pin_13| GPIO_Pin_14| GPIO_Pin_15;
	PortD.GPIO_Mode = GPIO_Mode_OUT;
	PortD.GPIO_OType = GPIO_OType_PP;
	PortD.GPIO_Speed = GPIO_Speed_100MHz;
	PortD.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOD, &PortD);

	PortA.GPIO_Pin =
	GPIO_Pin_5 | GPIO_Pin_7 |GPIO_Pin_8 |
	GPIO_Pin_2 | GPIO_Pin_3 |GPIO_Pin_4 |
	GPIO_Pin_9 |GPIO_Pin_10 |GPIO_Pin_15;
	PortA.GPIO_Mode = GPIO_Mode_OUT;
	PortA.GPIO_OType = GPIO_OType_PP;
	PortA.GPIO_Speed = GPIO_Speed_100MHz;
	PortA.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOA, &PortA);


	PortE.GPIO_Pin =
	GPIO_Pin_4 | GPIO_Pin_5 |GPIO_Pin_6 |
	GPIO_Pin_7 | GPIO_Pin_8 |GPIO_Pin_9 |
	GPIO_Pin_10 |GPIO_Pin_11 |GPIO_Pin_12;
	PortE.GPIO_Mode = GPIO_Mode_OUT;
	PortE.GPIO_OType = GPIO_OType_PP;
	PortE.GPIO_Speed = GPIO_Speed_100MHz;
	PortE.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOE, &PortE);
}
void initadc(){
	GPIO_InitTypeDef PortA;
		//inicjalizacja wej�cia ADC
	PortA.GPIO_Pin = GPIO_Pin_1;
	PortA.GPIO_Mode = GPIO_Mode_AN;
	PortA.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOA, &PortA);

	ADC_CommonInitTypeDef ADC_CommonInitStructure;
	// niezale�ny tryb pracy przetwornik�w
	ADC_CommonInitStructure.ADC_Mode = ADC_Mode_Independent;
	// zegar g��wny podzielony przez 2
	ADC_CommonInitStructure.ADC_Prescaler = ADC_Prescaler_Div2;
	// opcja istotna tylko dla trybu multi ADC
	ADC_CommonInitStructure.ADC_DMAAccessMode = ADC_DMAAccessMode_Disabled;
	// czas przerwy pomi�dzy kolejnymi konwersjami
	ADC_CommonInitStructure.ADC_TwoSamplingDelay = ADC_TwoSamplingDelay_5Cycles;
	ADC_CommonInit(&ADC_CommonInitStructure);

	ADC_InitTypeDef ADC_InitStructure;
	//ustawienie rozdzielczo�ci przetwornika na maksymaln� (12 bit�w)
	ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
	//wy��czenie trybu skanowania (odczytywa� b�dziemy jedno wej�cie ADC
	//w trybie skanowania automatycznie wykonywana jest konwersja na wielu //wej�ciach/kana�ach)
	ADC_InitStructure.ADC_ScanConvMode = DISABLE;
	//w��czenie ci�g�ego trybu pracy
	ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
	//wy��czenie zewn�trznego wyzwalania
	//konwersja mo�e by� wyzwalana timerem, stanem wej�cia itd. (szczeg�y w //dokumentacji)
	ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T1_CC1;
	ADC_InitStructure.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;
	//warto�� binarna wyniku b�dzie podawana z wyr�wnaniem do prawej
	//funkcja do odczytu stanu przetwornika ADC zwraca warto�� 16-bitow�
	//dla przyk�adu, warto�� 0xFF wyr�wnana w prawo to 0x00FF, w lewo 0x0FF0
	ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
	//liczba konwersji r�wna 1, bo 1 kana�
	ADC_InitStructure.ADC_NbrOfConversion = 1;
	// zapisz wype�nion� struktur� do rejestr�w przetwornika numer 1
	ADC_Init(ADC1, &ADC_InitStructure);
	ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 1, ADC_SampleTime_84Cycles);
	ADC_Cmd(ADC1, ENABLE);
}
void init_PWM(int period, int prescaler){
	//PORT B Sterowanie silnikiem 5 i 7
	TIM_TimeBaseInitTypeDef Timer4;
	Timer4.TIM_Period = period;
	Timer4.TIM_Prescaler = prescaler;
	Timer4.TIM_ClockDivision = TIM_CKD_DIV1;
	Timer4.TIM_CounterMode =  TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM4, &Timer4);
	TIM_Cmd(TIM4, ENABLE);
	GPIO_InitTypeDef PortB;
	PortB.GPIO_Pin =
//	SIL1		//PWMA		//SIL1		//PWMB		//SIL2		//SIL2
	GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7| GPIO_Pin_8| GPIO_Pin_9| GPIO_Pin_4;
	PortB.GPIO_Mode = GPIO_Mode_OUT;
	PortB.GPIO_OType = GPIO_OType_PP;
	PortB.GPIO_Speed = GPIO_Speed_100MHz;
	PortB.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(GPIOB, &PortB);

	TIM_OCInitTypeDef TIM_OCInitStructure;
	    /* PWM1 Mode configuration: */
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse = 0;
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;


	TIM_OC1Init(TIM4, &TIM_OCInitStructure);
	TIM_OC1PreloadConfig(TIM4, TIM_OCPreload_Enable);

	GPIO_PinAFConfig(GPIOB, GPIO_PinSource6, GPIO_AF_TIM4);
	PortB.GPIO_Pin = GPIO_Pin_6;
	PortB.GPIO_Mode = GPIO_Mode_AF;
	GPIO_Init(GPIOB, &PortB);


	TIM_OC3Init(TIM4, &TIM_OCInitStructure);
	TIM_OC3PreloadConfig(TIM4, TIM_OCPreload_Enable);

	GPIO_PinAFConfig(GPIOB, GPIO_PinSource8, GPIO_AF_TIM4);
	PortB.GPIO_Pin = GPIO_Pin_8;
	PortB.GPIO_Mode = GPIO_Mode_AF;
	GPIO_Init(GPIOB, &PortB);
	//7 i 5 silnik lewy
	GPIO_ResetBits(GPIOB,GPIO_Pin_7|GPIO_Pin_5);
	//
	GPIO_ResetBits(GPIOB, GPIO_Pin_9);
	GPIO_SetBits(GPIOB, GPIO_Pin_4);
	Kierunek = REST;
}
void Projekt_Init(){
	portD();//GPIO_ToggleBits(GPIOD,GPIO_Pin_12);
	initTimer3();//GPIO_ToggleBits(GPIOD,GPIO_Pin_13);
	initTimer2();
	initTimer6();
	initNVIC();//GPIO_ToggleBits(GPIOD,GPIO_Pin_14);
	init_PWM(99,41);
	initadc();
}
void SetSpeed(int speed, char dir){
	switch(dir){
	case 'l':
		TIM4->CCR1 = (speed+25 > 95 ? 70 : speed + 25);
		break;
	case 'r':
		TIM4->CCR3 = (speed+25 > 95 ? 70 : speed + 25);
		break;
	}
}
void Sterowanie(int Kier, char silnik){
switch(silnik){
case 'l':
	switch(Kier){
	case Przod:
		if(Kierunek == Przod)return;
		else {GPIO_ResetBits(GPIOB,GPIO_Pin_5 | GPIO_Pin_7);
		GPIO_SetBits(GPIOB,GPIO_Pin_7);
		}
		break;
	case Tyl:
		if(Kierunek == Tyl)return;
		else {GPIO_ResetBits(GPIOB,GPIO_Pin_5 | GPIO_Pin_7);
		GPIO_SetBits(GPIOB, GPIO_Pin_5);
		}
		break;
	case Stop:
		GPIO_ResetBits(GPIOB,GPIO_Pin_5 | GPIO_Pin_7);
		break;
	}
	break;

case 'r':
	switch(Kier){
	case Przod:
		if(Kierunek == Przod)return;
		else {GPIO_ResetBits(GPIOB,GPIO_Pin_4 | GPIO_Pin_9);
		GPIO_SetBits(GPIOB,GPIO_Pin_4);
		}
		break;
	case Tyl:
		if(Kierunek == Tyl)return;
		else {GPIO_ResetBits(GPIOB,GPIO_Pin_4 | GPIO_Pin_9);
		GPIO_SetBits(GPIOB, GPIO_Pin_9);
		}
		break;
	case Stop:
		GPIO_ResetBits(GPIOB,GPIO_Pin_4 | GPIO_Pin_9);
		break;
	}
	break;

}


}
void timer6(){
	TIM_TimeBaseInitTypeDef Timer6;
			Timer6.TIM_Period = 4199;
			Timer6.TIM_Prescaler = 9999;
			Timer6.TIM_ClockDivision = TIM_CKD_DIV1;
			Timer6.TIM_CounterMode =  TIM_CounterMode_Up;
			TIM_TimeBaseInit(TIM6, &Timer6);
			TIM_Cmd(TIM6, ENABLE);
}
int isBlack(x){return x>15;}

void main(){
	SystemInit();
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA , ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC , ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB , ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD , ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE , ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7, ENABLE);
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
//******CUSTOM FUNCTIONS FOR INIT
Projekt_Init();

	while (true){
		managedir();

	}

}
